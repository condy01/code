﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace TiianmaoShop
{
    [Serializable]
    public class Member : object

    {
        private int id;
        private int money;
        private string name;
        private string password;

        private static Dictionary<int, goods> buyList = new Dictionary<int, goods>();
        public Member(int id, string name, string password, int money)
        {
            this.id = id;
            this.name = name;
            this.password = password;
            this.Money = money;
        }

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Password { get => password; set => password = value; }
        public int Money { get => money; set => money = value; }
        public static Dictionary<int, goods> BuyList { get => buyList; set => buyList = value; }


        public void tostring1()
        {
            Console.WriteLine("-------------------------------------------购物车-----------------------------------------------");
            if (BuyList != null)
            {
                foreach (int s in BuyList.Keys)
                {
                    Console.WriteLine(BuyList[s].tostring());
                }
            }
            
            Console.WriteLine("------------------------------------------------------------------------------------------------");
        }

        public void tostring()
        {
            Console.WriteLine("----------------------------------------您的用户信息--------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("账号  ：" + this.Id);
            Console.WriteLine("用户名：" + this.Name);
            Console.WriteLine("金币：" + this.money );
            Console.WriteLine();
            tostring1();
        }

            public string tostring0()
        {
            string str = Id + '/' + Name + '/' + password + '/';
            return str;
        }


        public void change()
        {
            Console.WriteLine("请输入你的账户新账号:");
            int id = Input.input();
            Console.WriteLine("请输入你的账户新密码:");
            int password = Input.input();
        }
        public int Sum()
        {
            int sum = 0;
            foreach (int s in BuyList.Keys)
            {
                sum += BuyList[s].Money * BuyList[s].Number;
            }
            return sum;
        }

        public int number( int i)
        {
           return  BuyList[i].Number;
        }

            public void add(goods goods0,int i)
        {
            if (i == 0)
            {
                i = 1;
            }
            if (buyList == null)
            {
                BuyList.Add(goods0.Id, goods0);
            }
            else if (BuyList.ContainsKey(goods0.Id))
            {
                BuyList[goods0.Id].Number += i;
                //FFactory.SaveObject(face.path0, buyList);
            }
            else
            {
                BuyList.Add(goods0.Id, goods0);
                //FFactory.SaveObject(face.path0, buyList);
            }

        }
        public void remove(int i,int j)
        {
            if (BuyList[i]!=null)
            {
                BuyList[i].Number -= j;
            }
            else
            {
                BuyList.Remove(i);
                FFactory.SaveObject(face.path0, BuyList);
            }
            //buyList.Remove(i);
            //FFactory.SaveObject(face.path0, buyList);
        }
        public void RemoveAll()
        {
            BuyList = null;
        }
        }
}

