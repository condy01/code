﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiianmaoShop
{
    [Serializable]
    public class Login : object
    {
        Dictionary<int, Member> dict = null;



       public Login()
        {
            dict = new Dictionary<int, Member>();
        }



        public void regedit(int id, string userName, string password)
        {
            if (this.getUser(id) == null)
            {
                Member user = new Member(id, userName, password, 0);
                dict.Add(id, user);
            }
        }
        public Member getUser(int id)
        {
            if (dict.ContainsKey(id))
            {
                return dict[id];
            }
            return null;
        }
        
    }
}
