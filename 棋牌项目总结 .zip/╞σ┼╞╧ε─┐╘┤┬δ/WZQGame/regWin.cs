﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.core;
using util.net;

namespace WindowsFormsApp1
{
    public partial class regWin : Form
    {
        public byte[] imgByte { get; private set; }
        public string imgName { get; private set; }

        public regWin()
        {
            InitializeComponent();
        }

        private void regWin_Load(object sender, EventArgs e)
        {
            //EventDispatch.addEventListener(this, "com", this);
        }

        private void regWin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Login.f.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = this.id.Text;
            string name = this.name.Text;
            string sex;
            if (this.M.Checked)
            {
                sex= "男";
            }
            else
            {
                sex = "女";
            }
            int age = int.Parse(this.age.Text);
            string password = this.password.Text;
            string password3 = this.password3.Text;

            if (id.Length < 1)
            {
                MessageBox.Show("请输入账号！");
            }
            else if(name.Length < 1)
            {
                MessageBox.Show("请输入用户名！");
            }
            else if (password.Length < 1)
            {
                MessageBox.Show("请输入密码！");
            }
            else if (!password.Equals(password3))
            {
                MessageBox.Show("两次输入密码不一致！");
            }
            else if (age < 1)
            {
                MessageBox.Show("请输入年龄");
            }
            else
            {
                ByteBuffer buffer = ByteBuffer.CreateBufferAndLength(1002,1000*2000);

                buffer.writeString(id);
                buffer.writeString(name);
                buffer.writeString(sex);
                buffer.writeInt(age);
                buffer.writeString(password);

                buffer.writeInt(this.imgByte == null ? -1 : 1);
                if (this.imgByte != null)
                {
                    buffer.writeString(imgName);
                    buffer.writeInt(imgByte.Length);
                    buffer.writeBytes(imgByte);
                }
                //messageQueue message = new messageQueue();
                //message.StopRead();

                buffer.Send();

                U3DSocket u3DSocket = U3DSocket.shareSocket();
                
            }
            
            //u3DSocket.Close();
            //MessageBox.Show("注册成功", "登录提示");

        }
        
        private void connectError()
        {
            MessageBox.Show("注册失败");
        }
    
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login.f.Show();
            this.Close();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void password3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            /*
            string strPicPath = "";  // 存储路径
            OpenFileDialog openPic = new OpenFileDialog();
            openPic.Filter = "图片文件|*.bmp;*.jpg;*.jpeg;*.png";
            openPic.FilterIndex = 1;
            //openPic.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);//获取桌面文件夹路径为初始地址                                    
            if (openPic.ShowDialog() == DialogResult.OK)
            {
                //获取用户选择的文件，并判断文件大小不能超过20K，fileInfo.Length是以字节为单位的 
                FileInfo fileInfo = new FileInfo(openPic.FileName);
                if (fileInfo.Length > 2048000)
                {
                    MessageBox.Show("上传的图片不能大于2000K");
                }
                else
                {
                    strPicPath = openPic.FileName;
                    pictureBox1.BackgroundImage = Image.FromFile(strPicPath);  // picReceiptLogo是存储图片的路径
                }
            }*/
            this.openFileDialog1.Filter = "Image Files(*.BMP;*.JPG;*.GIF;*.PNG)|*.BMP;*.JPG;*.GIF;*.PNG" + "|All Files (*.*)|*.*";
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string path = this.openFileDialog1.FileName;
                    FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
                    if (fs.Length > 1000 * 1000)
                    {
                        MessageBox.Show("图片大小不能超过1M");
                    }
                    else
                    {
                        imgByte = new Byte[fs.Length];
                        this.imgName = path.Substring(path.LastIndexOf("\\") + 1);
                        //this.lab_path.Text = "位置:" + this.imgName;
                        //this.lab_size.Text = "大小:" + (imgByte.Length / 1000) + " KB  ";
                        fs.Read(imgByte, 0, imgByte.Length);
                        fs.Close();

                        Image m = Image.FromFile(path);
                        this.pictureBox1.Image = m;
                    }
                    
                }
                catch (Exception)
                {
                }
            }
        }
    }
}
