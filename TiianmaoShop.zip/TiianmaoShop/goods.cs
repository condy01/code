﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiianmaoShop
{
  public  class goods
    {
            private int id;
            private int money;
            private string name;
            private int number;

            public goods(int id, string name, int money,int number)
            {
                this.id = id;
                this.name = name;
                this.Number = number;
                this.Money = money;
            }

            public int Id { get => id; set => id = value; }
            public string Name { get => name; set => name = value; }
            public int Number { get => number; set => number = value; }
            public int Money { get => money; set => money = value; }

            public string tostring()
            {
                string str = Id + "     " + Name + "     " + money + "     " + number ;
                return str;
            }
            public void change()
            {
            }
      
    }
}
