﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.net;

namespace WindowsFormsApp1
{
    public partial class Game : Form
    {
       public static Game room=null;
        bool isxiaqi = false ;
        public Game()
        {
            InitializeComponent();

            //GameLogic g = new GameLogic(this);
            //ByteBuffer buffer = ByteBuffer.CreateBufferAndType(5001);
            //buffer.Send();
        }

        private void Game_Load(object sender, EventArgs e)
        {
            this.roomPassword.Hide();
            this.groupBox1.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }
        /*
         * //双击划线
        private void pictureBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Graphics g = this.pictureBox1.CreateGraphics();

            // g.DrawLine(Pens.White, new Point(0, 0), e.Location);

            // Graphics g = this.pictureBox1.CreateGraphics();
            //Point sp = new Point(0, 0);
            //Point endp = new Point(15, 15);
            //Pen p = new Pen(Color.Red, 2);
            for (int i = 0; i < 15; i++)
            {
                g.DrawLine(Pens.Blue, new Point(0, i * 35 + 5), new Point(this.pictureBox1.Width, i * 35 + 5));
                g.DrawLine(Pens.Blue, new Point(i * 35 + 5, 0), new Point(i * 35 + 5, this.pictureBox1.Height));
            }

        }
        */
        //显示棋子的坐标
        private void Game_MouseMove(object sender, MouseEventArgs e)
        {
            this.label1.Text = e.Location.X  + "," + e.Location.Y;//棋子的坐标
        }

        public void UpdateXiaQi(string username,int row,int col,int flg,string nex)
        {
            this.NewQiZi(row, col, flg);
            if (nex == Player.sharePlayer().Id)
            {
                this.isxiaqi = true;
                showMessageBox(true, "等待我方下棋");
            }
            else
            {
                this.isxiaqi = false;
                showMessageBox(true, "等待对方下棋");
            }
        }

        private void NewQiZi(int row,int col,int value)
        {
            PictureBox picture = new PictureBox();//新建picture类

            picture.Image = value > 0 ? Properties.Resources.bd1 : Properties.Resources.hd2;//背景图片
            picture.SizeMode = PictureBoxSizeMode.StretchImage;//设置图片缩放
            picture.Size = new Size(35, 35);//设置图片大小
            int x = col * 35 + 35 / 2 + 5 - picture.Width / 2;//棋子x坐标
            int y = row * 35 + 35 / 2 + 5 - picture.Width / 2;//棋子y坐标

            picture.Location = new Point(x, y);

            picture.BackColor = Color.Transparent;
            Checkerboard.Controls.Add(picture);
        }

        /// <summary>
        /// 鼠标单击添加棋子
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (isxiaqi)
            {
                isxiaqi = false;
                int row2 = (e.Location.X - 5) / 35;//棋子所在行数
                int row1 = (e.Location.Y - 5) / 35;//棋子所在列数
                this.label2.Text = row1 + "," + row2;

                ByteBuffer buffer = ByteBuffer.CreateBufferAndType(Protcol.玩家走棋);
                buffer.writeInt(row1);
                buffer.writeInt(row2);
                buffer.Send();
            }
        }

        /// <summary>
        /// 设置玩家位置，图片，信息
        /// </summary>
        /// <param name="id"></param>
        /// <param name="username"></param>
        /// <param name="img"></param>
        public void userAdd(string id,string username, string img)
        {
            Player p = Player.sharePlayer();
            if (id==p.Id)//如果是本人，把图片设置在下方
            {
                this.user2id.Text = id;
                this.user2name.Text = username;
                this.userpic2.LoadAsync(img == "null" ? null : img);
            }
            else//如果不是本人，把图片设置在上方
            {
                this.user1id.Text = id;
                this.user1name.Text = username;
                this.userpic1.LoadAsync(img == "null" ? null : img);
            }

        }
        /// <summary>
        /// 准备
        /// </summary>
        /// <param name="flg"></param>
        public void redy(int flg)
        {
            if (flg == -1)
            {
                this.ready1.Text = "未开始";
            }
            else
            {
                this.ready1.Text = "准备中";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }


        private void Form2_Load(object sender, EventArgs e)
        {
            //EventDispatch.addEventListener(this, "com", this);
        }

        private void ready_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text=="准备")
            {
                //向服务器发一个准备消息
                this.sendGameReadyOnCancel(1);
                
            }
            else
            {
                //向服务器发一个取消准备消息
                this.sendGameReadyOnCancel(-1);
            }
        }
        private void sendGameReadyOnCancel(int flg)
        {
            ByteBuffer buffer = ByteBuffer.CreateBufferAndType(flg > 0 ? Protcol.游戏准备 : Protcol.取消准备);
            buffer.writeInt(flg);
            buffer.Send();
        }
        public void gamestart(string name)
        {
            Player p = Player.sharePlayer();
            if (name == p.Id)
            {
                isxiaqi = true;
                showMessageBox(true, "等待我方先执棋");
            }
            else
            {
                showMessageBox(true, "等待对方先执棋");
            }
        }


        /// <summary>
        /// 准备
        /// </summary>
        /// <param name="flg"></param>
        public void showMessageBox(bool f=true  ,string str="")
        {
            this.wite.Text = str;
            if (f)
            {
                this.wite.Show();
            }
            else
            {
                this.wite.Hide();
            }
        }






        public void gameover(string id,string chinaname)
        {
            this.isxiaqi = false;
            if (id != null)
            {
                if (id == Player.sharePlayer().Id)
                {
                    //我方赢了
                    MessageBox.Show("我方胜利");
                }
                else
                {
                    MessageBox.Show(chinaname + "胜利");
                }
            }
            else
            {
                //我方赢了
                MessageBox.Show("我方胜利");
            }
            //清空棋盘
            Checkerboard.Controls.Clear();
            this.ready1.Show();
            this.ready2.Show();

        }



        private void Game_FormClosed(object sender, FormClosedEventArgs e)
        {
            room = null;
            ByteBuffer buffer = ByteBuffer.CreateBufferAndType(7999);
            buffer.Send();
        }

        private void password_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.roomPassword.Show();
            this.groupBox1.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if(this.roomid.Text.Length>6|| this.roomid.Text.Length < 3)
            {
                MessageBox.Show("密码不能低于三位，不能大于六位");
            }
            else
            {
                ByteBuffer buffer = ByteBuffer.CreateBufferAndType(7017);
                buffer.writeInt(int.Parse(this.roomid.Text));
                buffer.writeString(this.setRoomPassword.Text);
                buffer.Send();
                this.roomPassword.Hide();
                this.groupBox1.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.roomPassword.Hide();
            this.groupBox1.Hide();
        }
    }
}
