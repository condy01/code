﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiianmaoShop
{
    public class Debug//打印，输出
    {
        public static void Log(params object[] obj)
        {
            for (int i = 0; i < obj.Length; i++)
            {
                Console.Write(obj[i] + " ");
            }
        }
        public static void Logln(params object[] obj)
        {
            for (int i = 0; i < obj.Length; i++)
            {
                Console.WriteLine(obj[i]);
            }
            if (obj.Length <= 0)
            {
                Console.WriteLine();
            }
        }
    }
}
