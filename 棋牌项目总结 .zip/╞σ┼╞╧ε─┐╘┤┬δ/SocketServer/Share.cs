﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SocketServer
{
    public class Share
    {
        public static String USER_SAVE_PATH = "F:/Project/CshapProject/Project1/SocketServer/Users/";
        public static String USER_SAVE_IMAGE_PATH = "E:/SOFTSetUp/Tomcat7/webapps/ROOT/Users/";

        public static IPAddress IPAddress
        {
            get
            {
                IPHostEntry ipHost = Dns.Resolve(Dns.GetHostName());
                IPAddress ipAddr = ipHost.AddressList[0];
                return ipAddr;
            }
        }
    }
}
