﻿namespace WindowsFormsApp1
{
    partial class GameHall
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameHall));
            this.ChatMessage = new System.Windows.Forms.TextBox();
            this.oneTalk = new System.Windows.Forms.RadioButton();
            this.allTalk = new System.Windows.Forms.RadioButton();
            this.toName0 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.talk = new System.Windows.Forms.TextBox();
            this.onlineList = new System.Windows.Forms.ListView();
            this.账号 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.昵称 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.name = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.text = new System.Windows.Forms.TextBox();
            this.money = new System.Windows.Forms.Label();
            this.duanwei = new System.Windows.Forms.Label();
            this.pic = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).BeginInit();
            this.SuspendLayout();
            // 
            // ChatMessage
            // 
            this.ChatMessage.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ChatMessage.Enabled = false;
            this.ChatMessage.Location = new System.Drawing.Point(1098, 509);
            this.ChatMessage.Multiline = true;
            this.ChatMessage.Name = "ChatMessage";
            this.ChatMessage.ReadOnly = true;
            this.ChatMessage.Size = new System.Drawing.Size(308, 134);
            this.ChatMessage.TabIndex = 15;
            this.ChatMessage.TextChanged += new System.EventHandler(this.ChatMessage_TextChanged);
            // 
            // oneTalk
            // 
            this.oneTalk.AutoSize = true;
            this.oneTalk.Checked = true;
            this.oneTalk.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.oneTalk.Location = new System.Drawing.Point(1314, 649);
            this.oneTalk.Name = "oneTalk";
            this.oneTalk.Size = new System.Drawing.Size(58, 20);
            this.oneTalk.TabIndex = 14;
            this.oneTalk.TabStop = true;
            this.oneTalk.Text = "私聊";
            this.oneTalk.UseVisualStyleBackColor = true;
            // 
            // allTalk
            // 
            this.allTalk.AutoSize = true;
            this.allTalk.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.allTalk.Location = new System.Drawing.Point(1145, 649);
            this.allTalk.Name = "allTalk";
            this.allTalk.Size = new System.Drawing.Size(58, 20);
            this.allTalk.TabIndex = 13;
            this.allTalk.Text = "群聊";
            this.allTalk.UseVisualStyleBackColor = true;
            // 
            // toName0
            // 
            this.toName0.AutoSize = true;
            this.toName0.Location = new System.Drawing.Point(1099, 672);
            this.toName0.Name = "toName0";
            this.toName0.Size = new System.Drawing.Size(83, 12);
            this.toName0.TabIndex = 12;
            this.toName0.Text = "正在给 发消息";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(1314, 687);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 31);
            this.button1.TabIndex = 11;
            this.button1.Text = "发送";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // talk
            // 
            this.talk.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.talk.Location = new System.Drawing.Point(1101, 687);
            this.talk.Multiline = true;
            this.talk.Name = "talk";
            this.talk.Size = new System.Drawing.Size(241, 31);
            this.talk.TabIndex = 10;
            // 
            // onlineList
            // 
            this.onlineList.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.onlineList.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.onlineList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.账号,
            this.昵称});
            this.onlineList.FullRowSelect = true;
            this.onlineList.GridLines = true;
            this.onlineList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.onlineList.HideSelection = false;
            this.onlineList.HoverSelection = true;
            this.onlineList.Location = new System.Drawing.Point(1098, 256);
            this.onlineList.Name = "onlineList";
            this.onlineList.Size = new System.Drawing.Size(308, 228);
            this.onlineList.TabIndex = 9;
            this.onlineList.UseCompatibleStateImageBehavior = false;
            this.onlineList.View = System.Windows.Forms.View.Details;
            this.onlineList.MouseClick += new System.Windows.Forms.MouseEventHandler(this.onlineList_MouseClick);
            // 
            // 账号
            // 
            this.账号.Text = "账号";
            this.账号.Width = 87;
            // 
            // 昵称
            // 
            this.昵称.Text = "昵称";
            this.昵称.Width = 89;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AllowDrop = true;
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(22, 25);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1046, 693);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(234, 185);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(53, 12);
            this.linkLabel1.TabIndex = 17;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "修改资料";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(190, 44);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(77, 12);
            this.name.TabIndex = 18;
            this.name.Text = "用户名：1111";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.text);
            this.groupBox1.Controls.Add(this.money);
            this.groupBox1.Controls.Add(this.duanwei);
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Controls.Add(this.name);
            this.groupBox1.Controls.Add(this.pic);
            this.groupBox1.Location = new System.Drawing.Point(1098, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(308, 203);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "个人信息";
            // 
            // text
            // 
            this.text.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.text.Enabled = false;
            this.text.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.text.Location = new System.Drawing.Point(192, 114);
            this.text.Multiline = true;
            this.text.Name = "text";
            this.text.ReadOnly = true;
            this.text.Size = new System.Drawing.Size(95, 68);
            this.text.TabIndex = 20;
            // 
            // money
            // 
            this.money.AutoSize = true;
            this.money.Location = new System.Drawing.Point(190, 88);
            this.money.Name = "money";
            this.money.Size = new System.Drawing.Size(71, 12);
            this.money.TabIndex = 20;
            this.money.Text = "金币：10000";
            // 
            // duanwei
            // 
            this.duanwei.AutoSize = true;
            this.duanwei.Location = new System.Drawing.Point(190, 66);
            this.duanwei.Name = "duanwei";
            this.duanwei.Size = new System.Drawing.Size(29, 12);
            this.duanwei.TabIndex = 19;
            this.duanwei.Text = "青铜";
            // 
            // pic
            // 
            this.pic.Image = ((System.Drawing.Image)(resources.GetObject("pic.Image")));
            this.pic.Location = new System.Drawing.Point(26, 35);
            this.pic.Name = "pic";
            this.pic.Size = new System.Drawing.Size(133, 162);
            this.pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic.TabIndex = 16;
            this.pic.TabStop = false;
            // 
            // GameHall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1435, 747);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.ChatMessage);
            this.Controls.Add(this.oneTalk);
            this.Controls.Add(this.allTalk);
            this.Controls.Add(this.toName0);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.talk);
            this.Controls.Add(this.onlineList);
            this.Name = "GameHall";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "游戏大厅";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.GameHall_FormClosed);
            this.Load += new System.EventHandler(this.GameHall_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ColumnHeader 账号;
        private System.Windows.Forms.ColumnHeader 昵称;
        internal System.Windows.Forms.RadioButton oneTalk;
        internal System.Windows.Forms.RadioButton allTalk;
        internal System.Windows.Forms.Label toName0;
        internal System.Windows.Forms.Button button1;
        internal System.Windows.Forms.TextBox talk;
        internal System.Windows.Forms.TextBox ChatMessage;
        internal System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        internal System.Windows.Forms.ListView onlineList;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.TextBox text;
        internal System.Windows.Forms.PictureBox pic;
        internal System.Windows.Forms.Label name;
        internal System.Windows.Forms.Label money;
        internal System.Windows.Forms.Label duanwei;
    }
}