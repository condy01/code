﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiianmaoShop
{
    class Input//输入
    {

        public static int input()//输入一个字符,将字符转化为数字返回
        {
            while (true)
            {
                try
                {
                    int choose = Convert.ToInt32(Console.ReadLine());
                    return choose;
                }
                catch (ArgumentNullException)
                {
                    Console.WriteLine("输入错误，请重新输入!");
                }
                catch (FormatException)
                {
                    Console.WriteLine("输入错误，请重新输入!");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("输入错误，请重新输入!");
                }
            }
        }

       public static int[] input2()//,输入一个字符,将字符转化为以'/'分割数字数组返回，如输入“1/22”，返回{1,22}
        {
            while (true)
            {
                try
                {
                    string str = Console.ReadLine();
                    int a = 0;
                    for (int i = 0; i < str.Length; i++)
                    {
                        if (str[i] == '/')
                        {
                            a++;
                        }
                    }

                    if (a == 0)
                    {
                        string[] str2 = { str, "1" };
                        int b1 = Convert.ToInt32(str2[0]);
                        int b2 = Convert.ToInt32(str2[1]);
                        int[] str3 = { b1, b2 };
                        return str3;
                    }
                    else if (a == 1)
                    {
                        string[] str1 = str.Split('/');
                        int a1 = Convert.ToInt32(str1[0]);
                        int a2 = Convert.ToInt32(str1[1]);
                        int[] arr = { a1, a2 };
                        return arr;
                    }
                    else
                    {
                        Console.WriteLine("输入错误，请重新输入!");
                    }
                }
                catch (ArgumentNullException)
                {
                    Console.WriteLine("输入错误，请重新输入!");
                }
                catch (FormatException)
                {
                    Console.WriteLine("输入错误，请重新输入!");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("输入错误，请重新输入!");
                }
            }
        }


    }
}

