﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.core;
using util.net;

namespace WindowsFormsApp1
{
    public class GameHallLogic
    {


       public GameHall game=null;
        Dictionary<string, desk> deskList = new Dictionary<string, desk>();
        public GameHallLogic(GameHall g)
        {
            EventDispatch.addEventListener(this, "com");
            game = g;
        }

        public void com6210(ByteBuffer buffer)
        {
            while (buffer.Available > 0)
            {
                
                int roomId = buffer.readInt();//取房间id
                string roomName = buffer.readString();//获取房间号
                string password = buffer.readString();//获取房间密码
                int flg = buffer.readInt();
                //创建房间
                desk dt = new desk();
                dt.setRoomId(roomId.ToString());//设置房间号
                dt.setRoomName(roomName);//设置房间名字
                int userLeng = buffer.readInt();//获取玩家数
                while (userLeng > 0)
                {
                    string userName = buffer.readString();//获得玩家中文名
                    int deskPos = buffer.readInt();//玩家在左还是在右，左-1，右：1
                    string havImg = buffer.readString();//玩家图片，是一个地址
                    if (havImg == "null")
                    {
                        havImg = null;
                    }
                    dt.setUserName(userName, havImg, deskPos);
                    dt.setRoomState(flg);
                    userLeng--;
                }
                
                deskList.Add(roomId + "", dt);
                dt.Parent = game.flowLayoutPanel1;//设置父对象，把桌子添加到窗口显示

            }

        }
        public void com6211(ByteBuffer buffer)
        {
            int falg = buffer.readInt();
            if (falg > 0)
            {
                //加入房间
                int roomId = buffer.readInt();//取房间id
                string userName = buffer.readString();//获取房间号
                int post = buffer.readInt();//位置左右
                string Img = buffer.readString();//玩家图片
                //通过房间号得到桌子
                desk desk = this.deskList[roomId+""];
                desk.setUserName(userName, Img == "null" ? null:Img,post);
            }
            else
            {
                //离开房间
                int roomId = buffer.readInt();
                int post = buffer.readInt();
                desk desk = this.deskList[roomId + ""];
                desk.removeUser(post);
            }
        }
        //玩家第一次进入大厅的时候，把所有消息发下来
        public void com6550(ByteBuffer buffer)
        {
            while (buffer.Available > 0)
            {
                string _name = buffer.readString();
                string _cname = buffer.readString();
                ListViewItem item = new ListViewItem();
                item.Text = _name;
                item.SubItems.Add(_cname);
                game.onlineList.Items.Add(item);
            }

        }
        //大厅用户列表，某个用户进入了大厅
        public void com6551(ByteBuffer buffer)
        {
            string _name = buffer.readString();
            string _cname = buffer.readString();
            ListViewItem item = new ListViewItem();
            item.Text = _name;
            item.SubItems.Add(_cname);
            game.onlineList.Items.Add(item);
        }
        //某个玩家退出
        public void com6555(ByteBuffer buffer)
        {
            string _name = buffer.readString();
            int count = game.onlineList.Items.Count;
            for (int i = 0; i < count; i++)
            {
                string s = game.onlineList.Items[i].Text;
                if (s.Equals(_name))
                {
                    game.onlineList.Items.RemoveAt(i);
                    break;
                }
            }
            //ListViewItem item = new ListViewItem();
            //this.onlineList.Items.Remove(item);
        }






            /*
    public void com1003(ByteBuffer buffer)
    {
        int a = buffer.readInt();
        //MessageBox.Show(a+"");
        string b = buffer.readString();
        string c = buffer.readString();
        if (a == -1)
        {
            //MessageBox.Show(b + " " + c + "离开");
            ListViewItem item = new ListViewItem();
            //删除一行的方法
            for (int i = 0; i < onlineList.Items.Count; i++)
            {
                if (onlineList.Items[i].SubItems[0].Text == b)
                {
                    onlineList.Items.RemoveAt(i);
                    i--;
                }
            }
        }
        else
        {
            //MessageBox.Show(b + " " + c + "进入");
            ListViewItem item = new ListViewItem();
            //添加一行的方法
            item.Text = b;
            //依次添加后面列的数据：
            item.SubItems.Add(c);

            onlineList.Items.Add(item);
        }
    }*/
            
            public void com2001(ByteBuffer buffer)
            {
                string str1 = buffer.readString();
                string str2 = buffer.readString();
                string str3 = buffer.readString();
                ListViewItem item = new ListViewItem();
            //添加一行的方法
            //ChatRecord.Items.Add(str2+"【"+ str1 + "】"+"对大家说："+ str3);
            game.ChatMessage.Text += str2 + "【" + str1 + "】" + "对大家说：" + str3 + "\r\n";
            }
            public void com2002(ByteBuffer buffer)
            {
                string str1 = buffer.readString();
                string str2 = buffer.readString();
                string str3 = buffer.readString();
                ListViewItem item = new ListViewItem();
            //添加一行的方法
            //ChatRecord.Items.Add(str2 + "【" + str1 + "】" + "私聊你说：" + str3);
            game.ChatMessage.Text += str2 + "【" + str1 + "】" + "私聊你说：" + str3 + "\r\n";
            }

        public void com7005(ByteBuffer buffer)
        {
            int ID = buffer.readInt();
            int flg = buffer.readInt();

            this.deskList[ID + ""].setRoomState(flg);

        }
        public void com7018(ByteBuffer buffer)
        {
            int roomId = buffer.readInt();
            inputPassword arp = new inputPassword();
            arp.Show();
        }
        public void com7010(ByteBuffer buffer)
        {
            string str = buffer.readString();
        }
        /*
            public void com5001(ByteBuffer buffer)
            {
                string msg = buffer.readString();

                string[] a = new string[1000];
                string[] b = new string[a.Length];
                string[] c = new string[a.Length];
                a = msg.Split('@');
                for (int i = 0; i < a.Length; i++)
                {
                    b[i] = a[i].Split('#')[1];
                    c[i] = a[i].Split('#')[0];
                }

                for (int i = 0; i < a.Length; i++)
                {
                    ListViewItem item = new ListViewItem();
                    //添加一行的方法
                    item.Text = b[i];
                    //依次添加后面列的数据：
                    item.SubItems.Add(c[i]);

                    onlineList.Items.Add(item);
                    //onlineList.Items.Add(c[i]);
                }
                //MessageBox.Show(msg);

            }
            */

        /*
            public void com6210(ByteBuffer buffer)
        {
            while (buffer.Available > 0)
            {
                desk desk = new desk();
                //GameHall.add(desk);
                int id = buffer.readInt();
                string name = buffer.readString();
                desk.setRoomName(name + "");
                deskList.Add(id + "", desk);
                desk.setRoomId(id+"");
                this.flowLayoutPanel1.Controls.Add(desk);
            }
        }
        public void com6211(ByteBuffer buffer)
        {
            int roomId = buffer.readInt();
            string name = buffer.readString();
            int deskPos = buffer.readInt();
            int havImg = buffer.readInt();
            Image img = null;
            if (havImg>0)
            {
                ByteBuffer buffer1 = buffer.readBuffer();
                Stream stream = new MemoryStream(buffer1.getBuffer());
                img = Image.FromStream(stream);
            }
            desk dt = deskList[roomId.ToString()];
            dt.setUserName1(name, img);

        }
        */
        /*
        public void com6310(ByteBuffer buffer)
        {


        }
        */






    }
}
