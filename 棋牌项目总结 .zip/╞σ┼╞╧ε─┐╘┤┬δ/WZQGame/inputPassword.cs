﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.net;

namespace WindowsFormsApp1
{
    public partial class inputPassword : Form
    {
        private int id;

        public inputPassword(int rid)
        {
            id = rid;
        }
        public inputPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = this.password.Text;
            ByteBuffer buffer = ByteBuffer.CreateBufferAndType(6310);
            buffer.writeInt(this.id);
            buffer.writeString(str);
            buffer.Send();
            this.Close();
        }
    }
}
