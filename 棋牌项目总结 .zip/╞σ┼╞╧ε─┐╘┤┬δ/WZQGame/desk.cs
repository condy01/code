﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.core;
using util.net;

namespace WindowsFormsApp1
{
    public partial class desk : UserControl
    {

        public string password = null;
        public string deskname = null;
        public bool leftset = false;
        private string deskid = null;

        public string Deskid { get => deskid; set => deskid = value; }

        public desk()
        {
            InitializeComponent();
        }

        private void desk_Load(object sender, EventArgs e)
        {
            //EventDispatch.addEventListener(this, "com", this);
        }
        public Label getUser1()
        {
            return this.User1;
        }
        public Label getUser2()
        {
            return this.User2;
        }
        public string getRoomId()
        {
            return this.deskNumber.Text ;
        }
        public string getRoomName()
        {
            return this.DeskName.Text;
        }
        public void setRoomName(string name)
        {
            this.DeskName.Text = name;
        }
        public void setRoomId(string id)
        {
            this.deskNumber.Text = id;
        }
            public void setUserName1(string name)
        {
            this.User1.Text = name;
        }
        public void setUserName2(string name)
        {
            this.User2.Text = name;
        }
        public void setRoomState(int flg)
        {
            if (flg < 0)
            {
                this.ing.Text = "空闲中";
            }
            else if (flg == 0)
            {
                this.ing.Text = "等待中";
            }
            else
            {
                this.ing.Text = "游戏中";
            }
        }
        public void setUserName(string uName, string imgUrl=null,int leftOrRight=-1)
        {
            if (leftOrRight < 0)
            {
                this.User1.Text = uName;
                if (imgUrl != null)
                {
                    this.pic_left_img.LoadAsync(imgUrl);
                }
            }
            else
            {
                this.User2.Text = uName;
                if (imgUrl != null)
                {
                    this.pic_right_img.LoadAsync(imgUrl);
                }
            }
        }

        public void removeUser(int pos)
        {
            if (pos < 0)
            {
                this.User1.Text = "";
                this.pic_left_img.Image = Properties.Resources.QQ图片20190719094038;
            }
            else
            {
                this.User2.Text = "";
                this.pic_right_img.Image = Properties.Resources.QQ图片20190719094038;

            }
        }
        /*
            public void setUserName1(string uName,Image img=null)
        {
            if (img != null)
            {
                this.pic_left_img.Image = img;
            }
            this.User1.Text = uName;
        }
        public void setUserName2(string uName, Image img = null)
        {
            if (img != null)
            {
                this.pic_left_img.Image = img;
            }
            this.User2.Text = uName;
        }
        */
        private void pictureBox3_DoubleClick(object sender, EventArgs e)
        {
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void addRoom_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ByteBuffer byteBuffer = ByteBuffer.CreateBufferAndType(6310);
            byteBuffer.writeInt(int.Parse(getRoomId()));
            byteBuffer.writeString("");
            byteBuffer.Send();
        }

    }
}
