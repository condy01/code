﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.core;
using util.net;

namespace WindowsFormsApp1
{
    class GameLogic
    {

        public Game gameroom = null;


        public GameLogic()
        {
            EventDispatch.addEventListener(this, "com");
        }
        //玩家自己第一次进入房间
        public void com7000(ByteBuffer buffer)
        {
            if (Game.room == null)
            {
                gameroom = new Game();
                gameroom.Show();
                
            }
            int roomid = buffer.readInt();
            string roomname = buffer.readString();
            string password = buffer.readString();
            gameroom.roomName.Text = roomname;
            gameroom.roomid.Text = roomid+"";
            int userCount = buffer.readInt();

            while (userCount > 0)
            {
                string id = buffer.readString();
                string username = buffer.readString();
                int deskPos = buffer.readInt();
                string img = buffer.readString();
                int redy = buffer.readInt();
                gameroom.userAdd(id, username, img == "null" ? null : img);

                ListViewItem item = new ListViewItem();
                item.Text = id;
                item.SubItems.Add(username);
                gameroom.onlineList.Items.Add(item);

                gameroom.redy(redy);
                userCount--;
            }

        }
        //房间用户列表，某个用户进入了房间
        public void com7001(ByteBuffer buffer)
        {
            string id = buffer.readString();
            string username = buffer.readString();
            int deskPos = buffer.readInt();
            string img = buffer.readString();
            Player p = Player.sharePlayer();
            if (id == p.Id) return;//如果是本人
            gameroom.userAdd(id, username, img == "null" ? null : img);

            ListViewItem item = new ListViewItem();
            item.Text = id;
            item.SubItems.Add(username);
            gameroom.onlineList.Items.Add(item);

        }


        public void com7006(ByteBuffer buffer)
        {
            string name = buffer.readString();
            Player p = Player.sharePlayer();
            if (name == p.Id)
            {
                gameroom.ready2.Text = "取消准备";
                gameroom.ready2.Enabled = true;
            }
            else
            {
                gameroom.ready1.Text = "准备中";
            }

        }

        public void com7007(ByteBuffer buffer)
        {
            string name = buffer.readString();
            Player p = Player.sharePlayer();
            if (name == p.Id)
            {
                gameroom.ready2.Text = "准备";
            }
            else
            {
                gameroom.ready1.Text = "未开始";

            }

        }

        //游戏开始
        public void com7100(ByteBuffer buffer)
        {
            string name = buffer.readString();
            gameroom.ready1.Hide();
            gameroom.ready2.Hide();

            gameroom.gamestart(name);
        }
        public void com7111(ByteBuffer buffer)
        {
            string username = buffer.readString();
            int row1 = buffer.readInt();
            int row2 = buffer.readInt();
            int flg = buffer.readInt();
            string username2 = buffer.readString();
            gameroom.UpdateXiaQi(username,row1, row2, flg, username2);
        }

        public void com7119(ByteBuffer buffer)
        {
            //游戏开始后
            //玩家中途走了7999
            //玩家结束后走了7199
            int flg = buffer.readInt();//1正常结束，-1中途退出
            if (flg>0)
            {
                string id = buffer.readString();
                string username = buffer.readString();
                gameroom.gameover(id, username);
            }
            else
            {
                gameroom.gameover("", "");
            }
        }
        //玩家离开房间
        public void com7999(ByteBuffer buffer)
        {
            string id = buffer.readString();
            //int deskPos = buffer.readInt();

            for (int i = 0; i < gameroom.onlineList.Items.Count; i++)
            {
                string s = gameroom.onlineList.Items[i].Text;
                if (s.Equals(id))
                {
                    gameroom.onlineList.Items.RemoveAt(i);
                    break;
                }
            }
            gameroom.user1id.Text = "";
            gameroom.user1name.Text = "";
            gameroom.userpic1.Image = Properties.Resources.QQ图片20190719094038;
            gameroom.wite.Hide();
            
            //desk d = new desk();
            //d.removeUser(deskPos);
        }

            /*

            public void com1003(ByteBuffer buffer)
            {
                int a = buffer.readInt();
                //MessageBox.Show(a+"");
                string b = buffer.readString();
                string c = buffer.readString();
                if (a == -1)
                {
                    //MessageBox.Show(b + " " + c + "离开");
                    ListViewItem item = new ListViewItem();
                    //删除一行的方法
                    for (int i = 0; i < onlineList.Items.Count; i++)
                    {
                        if (onlineList.Items[i].SubItems[0].Text == b)
                        {
                            onlineList.Items.RemoveAt(i);
                            i--;
                        }
                    }
                }
                else
                {
                    //MessageBox.Show(b + " " + c + "进入");
                    ListViewItem item = new ListViewItem();
                    //添加一行的方法
                    item.Text = b;
                    //依次添加后面列的数据：
                    item.SubItems.Add(c);

                    onlineList.Items.Add(item);
                }
            }
            
            public void com2001(ByteBuffer buffer)
            {
                string str1 = buffer.readString();
                string str2 = buffer.readString();
                string str3 = buffer.readString();
                ListViewItem item = new ListViewItem();
                //添加一行的方法
                //ChatRecord.Items.Add(str2+"【"+ str1 + "】"+"对大家说："+ str3);
                 ChatMessage.Text += str2 + "【" + str1 + "】" + "对大家说：" + str3 + "\r\n";
            }
            public void com2002(ByteBuffer buffer)
            {
                string str1 = buffer.readString();
                string str2 = buffer.readString();
                string str3 = buffer.readString();
                ListViewItem item = new ListViewItem();
                //添加一行的方法
                //ChatRecord.Items.Add(str2 + "【" + str1 + "】" + "私聊你说：" + str3);
                ChatMessage.Text += str2 + "【" + str1 + "】" + "私聊你说：" + str3 + "\r\n";
            }
        
            public void com5001(ByteBuffer buffer)
            {
                string msg = buffer.readString();

                string[] a = new string[1000];
                string[] b = new string[a.Length];
                string[] c = new string[a.Length];
                a = msg.Split('@');
                for (int i = 0; i < a.Length; i++)
                {
                    b[i] = a[i].Split('#')[1];
                    c[i] = a[i].Split('#')[0];
                }

                for (int i = 0; i < a.Length; i++)
                {
                    ListViewItem item = new ListViewItem();
                    //添加一行的方法
                    item.Text = b[i];
                    //依次添加后面列的数据：
                    item.SubItems.Add(c[i]);

                    onlineList.Items.Add(item);
                    //onlineList.Items.Add(c[i]);
                }
                //MessageBox.Show(msg);

            }


            private void onlineList_Click(object sender, EventArgs e)
            {
                //ListView list = (ListView)sender;

                String STR = onlineList.SelectedItems[0].Text;
                //String STR = list.SelectedItems[0].Text;
                //MessageBox.Show(STR);
                toName.Text = "正在给" + STR + "发消息";
            }

            private void Button1_Click(object sender, EventArgs e)
            {
                if (this.allTalk.Checked)
                {
                    ByteBuffer byteBuffer = ByteBuffer.CreateBufferAndType(2001);
                    string str = this.talk.Text;
                    byteBuffer.writeString(str);
                    byteBuffer.Send();
                    this.talk.Text = null;
                }
                else
                {
                    ByteBuffer byteBuffer = ByteBuffer.CreateBufferAndType(2002);
                    string str = this.talk.Text;
                    string name = onlineList.SelectedItems[0].SubItems[1].Text;
                    if (name == null)
                    {
                        MessageBox.Show("请选择要私聊的对象！");
                    }
                    else
                    {
                        byteBuffer.writeString(name);
                        byteBuffer.writeString(str);
                        byteBuffer.Send();
                        this.talk.Text = null;
                    }
                }
             */
        }
}
