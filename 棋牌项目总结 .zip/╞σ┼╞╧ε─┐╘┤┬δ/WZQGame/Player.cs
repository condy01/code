﻿using System;

namespace WindowsFormsApp1
{
    internal class Player
    {
       private string id;
        private string name;
        private string pic;

       static Player player;

        public string Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Pic { get => pic; set => pic = value; }
        public int money { get; internal set; }
        public string Duanwei { get; internal set; }
        public string text { get; internal set; }
        public string img { get; internal set; }

        internal static Player sharePlayer()
        {
            if (player == null)
            {
                player = new Player();
            }
            return player;
        }
    }
}