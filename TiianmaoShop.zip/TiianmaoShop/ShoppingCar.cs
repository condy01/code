﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiianmaoShop
{
    class ShoppingCar
    {
        List<goods> buyList = new List<goods>();
        public void Add(goods g)
        {
            buyList.Add(g);
        }
    }

}

