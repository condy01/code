﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class Protcol
    {
        public static int 游戏准备 = 7006;
        public static int 取消准备 = 7007;
        public static int 玩家走棋 = 7111;
        public static int 离开房间 = 7999;
    }
}
