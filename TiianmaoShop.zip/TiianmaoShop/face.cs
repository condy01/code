﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiianmaoShop
{
    class face//界面
    {
        
        public static string path0 = @"../../data/member.txt";//用户
        //public static string path = @"F:\c#\TiianmaoShop\TiianmaoShop\data\list.txt";//购物车
        static string path1 = @"../../data/things1.xml";//商品
        static string path2 = @"../../data/things2.xml";
        static string path3 = @"../../data/things3.xml";
        static string path4 = @"../../data/things4.xml";
             
        /*
   public static string path0 = @"F:\c#\TiianmaoShop\TiianmaoShop\data\member.txt";//用户
   //public static string path = @"F:\c#\TiianmaoShop\TiianmaoShop\data\list.txt";//购物车
   static string path1 = @"F:\c#\TiianmaoShop\TiianmaoShop\data\things1.xml";//商品
   static string path2 = @"F:\c#\TiianmaoShop\TiianmaoShop\data\things2.xml";
   static string path3 = @"F:\c#\TiianmaoShop\TiianmaoShop\data\things3.xml";
   static string path4 = @"F:\c#\TiianmaoShop\TiianmaoShop\data\things4.xml";
       */
        static Login login0 = FFactory.ReadObject<Login>(path0);

        //static Member member0 = FFactory.ReadObject<Member>(path);



        saveAndRead saveAndRead0 = new saveAndRead();

        public static void longinLayer()
        {
            Console.WriteLine("--------------------------------------欢迎来到天猫超市------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("                             1.登录                           2.注册                            ");
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("请选择：");
            int a = Input.input();
            switch (a)
            {
                
                case (1): login(); break;
                case (2): Register(); break;
                default: Console.Clear(); Debug.Logln("输入错误，请重新输入！"); longinLayer(); break;
            }

        }
        public static void login()
        {
            Console.WriteLine("请输入你的账户账号:");
            int id = Input.input();
            Console.WriteLine("请输入你的账户密码:");
            string password = Console.ReadLine();




            if (login0.getUser(id) == null)
            {
                Console.Clear();
                Console.WriteLine("登录失败，请检查你输入的账号是否有误！");
                longinLayer();
            }
            else
            {
                string name = login0.getUser(id).Name;

                string password1 = login0.getUser(id).Password;

                if (password == password1)
                {

                    //Member member = new Member(id, name, password, 0);

                    Console.Clear();
                    Console.WriteLine("登录成功！");
                    Console.WriteLine("欢迎" + name);
                    MainLayer(id);
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("登录失败，请检查你输入的密码是否有误！");
                    longinLayer();
                }
            }
        }


        public static void Register()
        {
            Console.WriteLine("请输入你的账户账号:");
            int id = Input.input();
            Console.WriteLine("请输入你的账户用户名:");
            string name = Console.ReadLine();
            Console.WriteLine("请输入你的账户密码:");
            string password = Console.ReadLine();

            if (login0.getUser(id) == null)
            {
                login0.regedit(id, name, password);
                FFactory.SaveObject(path0, login0);
                Console.Clear();
                Console.WriteLine("恭喜您注册成功！请登录");
                login();


            }
            else
            {
                Console.Clear();
                Console.WriteLine("用户已存在");
                login();
            }

        }


        public static void MainLayer(int id)
        {
            Console.WriteLine("--------------------------------------欢迎来到天猫超市------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("                             1001       进入天猫商场                                            ");
            Console.WriteLine();
            Console.WriteLine("                             1002       查看用户数据                                            ");
            Console.WriteLine();
            Console.WriteLine("                             1003       收银台结算                                              ");
            Console.WriteLine();
            Console.WriteLine("                             1004       充值系统                                                ");
            Console.WriteLine();
            Console.WriteLine("                             1005       退出系统                                                ");
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("请选择：");
            int a = Input.input();
            switch (a)
            {
                case (1001): Console.Clear(); shopLayer(id); break;
                case (1002): Console.Clear(); dataLayer(id); break;
                case (1003): Console.Clear(); summanyLayer(id); break;
                case (1004): Console.Clear(); addmoneyLayer(id); break;
                case (1005): exit(); break;
                default: Console.Clear(); Debug.Log("输入错误，请重新输入！"); MainLayer(id); break;
            }
        }

        public static void shopLayer(int id)
        {
            Console.WriteLine("--------------------------------------欢迎来到天猫商场------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("                             1001       手机店                                            ");
            Console.WriteLine();
            Console.WriteLine("                             1002       服装店                                            ");
            Console.WriteLine();
            Console.WriteLine("                             1003       食品店                                              ");
            Console.WriteLine();
            Console.WriteLine("                             1004       饰品店                                                ");
            Console.WriteLine();
            Console.WriteLine("                             1005       返回                                                ");
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("请选择：");
            int a = Input.input();
            switch (a)
            {
                case (1001): Console.Clear(); phoneshop(id); break;
                case (1002): Console.Clear(); clothesshop(id); break;
                case (1003): Console.Clear(); foodshop(id); break;
                case (1004): Console.Clear(); ringshop(id); break;
                case (1005): Console.Clear(); MainLayer(id); break;
                default: Console.Clear(); Debug.Log("输入错误，请重新输入！"); MainLayer(id); break;
            }

            //saveAndRead.readXML(path1).ToList();

        }

        public static void buy(Dictionary<int, goods> i)
        {
            int[] a = Input.input2();
            goods goods0 = new goods(i[a[0]].Id, i[a[0]].Name, i[a[0]].Money, i[a[0]].Number - a[1]);
            i[a[0]] = goods0;
            saveAndRead.change(path1, a[0], i);
            Console.Clear();
            Console.WriteLine("购买成功！");
        }


        public static void ShoppingCar(int id)
        {
            login0.getUser(id).tostring1();
            Console.WriteLine("请选择：");
            Console.WriteLine("1：付款");
            Console.WriteLine("2：继续购物");
            int b = Input.input();
            while (true)
            {
                switch (b)
                {
                    case (1): Console.Clear(); ShoppingCar(id); break;
                    case (2): Console.Clear(); shopLayer(id); break;
                    default: Console.Clear(); Debug.Log("输入错误，请重新输入！"); break;
                }

            }
        }


        public static void add(int id, Dictionary<int, goods> i,string path1)
        {
 
            List<goods> list = saveAndRead.readXML(path1).Values.ToList();

            foreach (goods s in list)
            {
                Console.WriteLine(s.tostring());
            }
            Console.WriteLine("请选择你要购买的商品编号/数量：[按0返回]");
            int[] a = Input.input2();
            if (a[0] == 0)//判断输入是0时退出
            {
                Console.Clear();
                shopLayer(id);
            }
            else if (i.ContainsKey(a[0]))
            {
                if (i[a[0]].Number <= 0)//判断库存
                {
                    Console.WriteLine("购买失败，库存不足！");
                    Console.Clear();
                }
                else if (a[1] > i[a[0]].Number)//添加数量大于库存
                {
                    a[1] = i[a[0]].Number;
                    goods goods0 = new goods(i[a[0]].Id, i[a[0]].Name, i[a[0]].Money, a[1]);
                    login0.getUser(id).add(goods0, a[1]);
                    goods goods2 = new goods(i[a[0]].Id, i[a[0]].Name, i[a[0]].Money, i[a[0]].Number -= a[1]);
                    i[a[0]] = goods2;
                    saveAndRead.change(path1, a[0], i);

                    FFactory.SaveObject(path0, login0);

                    Console.Clear();
                    Console.WriteLine("数量超出库存，改为添加最大可购买数量！");//
                    Console.WriteLine("已成功添加到购物车！");
                }
                else
                {
                    goods goods0 = new goods(i[a[0]].Id, i[a[0]].Name, i[a[0]].Money, a[1]);
                    login0.getUser(id).add(goods0, a[1]);
                    goods goods2 = new goods(i[a[0]].Id, i[a[0]].Name, i[a[0]].Money, i[a[0]].Number -= a[1]);
                    i[a[0]] = goods2;
                    saveAndRead.change(path1, a[0], i);

                    FFactory.SaveObject(path0, login0);

                    Console.Clear();
                    Console.WriteLine("已成功添加到购物车！");
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("输入错误，请重新输入！");
            }

        }

            public static void buyOK(int id)
        {
            Console.Clear();
            Console.WriteLine("已成功添加到购物车！");
            Console.WriteLine("1：查看购物车");
            Console.WriteLine("2：继续购物");
            int b = Input.input();
            while (true)
            {
                switch (b)
                {
                    case (1): Console.Clear(); ShoppingCar(id); break;
                    case (2): Console.Clear(); phoneshop(id); break;
                    default: Console.Clear(); Debug.Logln("输入错误，请重新输入！"); buyOK(id); break;
                }

            }
        }
        
        public static void phoneshop(int id)
        {
            Dictionary<int, goods> i = saveAndRead.readXML(path1);

            add(id, i, path1);

            phoneshop(id);
        }

        public static void clothesshop(int id)
        {
            Dictionary<int, goods> i = saveAndRead.readXML(path2);

            add(id, i, path2);

            clothesshop(id);
        }
        public static void foodshop(int id)
        {
            Dictionary<int, goods> i = saveAndRead.readXML(path3);

            add(id, i, path3);

            foodshop(id);
        }
        public static void ringshop(int id)
        {
            Dictionary<int, goods> i = saveAndRead.readXML(path4);

            add(id, i, path4);

            ringshop(id);
        }
        
        public static void dataLayer(int id)
        {
            login0.getUser(id).tostring();
            Console.WriteLine("请选择！");
            Console.WriteLine("1：继续购物");
            Console.WriteLine("2：删除商品");
            Console.WriteLine("3：结算");
            int b = Input.input();
            while (true)
            {
                switch (b)
                {
                    case (1): Console.Clear(); shopLayer(id); break;
                    case (2): Console.Clear(); deleteLayer(id); break;
                    case (3): Console.Clear(); summanyLayer(id); break;
                    default: Console.Clear(); Debug.Log("输入错误，请重新输入！"); buyOK(id); break;
                }

            }
        }
        public static void deleteLayer(int id)
        {
            Dictionary<int, goods> i1 = saveAndRead.readXML(path1);
            Dictionary<int, goods> i2 = saveAndRead.readXML(path2);
            Dictionary<int, goods> i3 = saveAndRead.readXML(path3);
            Dictionary<int, goods> i4 = saveAndRead.readXML(path4);
            List<goods> list = saveAndRead.readXML(path1).Values.ToList();

            login0.getUser(id).tostring1();
            Console.WriteLine("请选择你要移除的商品编号/数量：[按0返回]");
            int[] a = Input.input2();
            if (a[0] == 0)//判断输入是0时退出
            {
                Console.Clear();
                shopLayer(id);
            }
            else if (i1.ContainsKey(a[0])|| i2.ContainsKey(a[0]) || i3.ContainsKey(a[0]) || i4.ContainsKey(a[0]))
            {
                if (a[1]<=0)
                {
                    Console.Clear();
                    Console.WriteLine("输入错误，请重新输入！");
                    deleteLayer(id);
                }
                else if (a[1] > login0.getUser(id).number(a[0]))//删除的数量大于商品数量
                {
                    Console.Clear();
                    Console.WriteLine("数量超出，请重新输入！");
                    deleteLayer(id);
                }
                else
                {
                    if (i1.ContainsKey(a[0]))
                    {
                        delete(id, i1, a);
                    }
                    else if(i2.ContainsKey(a[0]))
                    {
                        delete(id, i2, a);
                    }
                    else if (i3.ContainsKey(a[0]))
                    {
                        delete(id, i3, a);
                    }
                    else if(i4.ContainsKey(a[0]))
                    {
                        delete(id, i4, a);
                    }
                    else
                    {
                        Console.Clear();
                        dataLayer(id);
                    }

                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("输入错误，请重新输入！");
                deleteLayer(id);
            }
        }

        public static void delete(int id, Dictionary<int, goods> i, int[] a)
        {
            login0.getUser(id).remove(a[0], a[1]);
            goods goods2 = new goods(i[a[0]].Id, i[a[0]].Name, i[a[0]].Money, i[a[0]].Number += a[1]);
            i[a[0]] = goods2;
            saveAndRead.change(path1, a[0], i);
            FFactory.SaveObject(path0, login0);
            Console.Clear();
            Console.WriteLine("已成功将商品移除出购物车！");
            dataLayer(id);
        }


            public static void summanyLayer(int id)
        {
            Dictionary<int, goods> i = saveAndRead.readXML(path1);
            login0.getUser(id).tostring1();
            int sum = login0.getUser(id).Sum();
            Console.WriteLine("合计："+ sum);
            Console.WriteLine("请选择！");
            Console.WriteLine("1：返回");
            Console.WriteLine("2：结算");
            int b = Input.input();
            while (true)
            {
                switch (b)
                {
                    case (1):
                        Console.Clear();
                        MainLayer(id);
                        break;
                    case (2):
                        if (sum <= login0.getUser(id).Money)//判断金钱
                        {
                            login0.getUser(id).RemoveAll();
                            login0.getUser(id).Money -= sum;
                            Console.Clear();
                            Console.WriteLine("购买成功！");
                            MainLayer(id);
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("金钱不足，请充值！");
                            MainLayer(id);
                        }
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("输入错误！");
                        summanyLayer(id);
                        break;
                }
            }
        }

        public static void addmoneyLayer(int id)
        {

            Console.WriteLine("请输入你要充值的金币数额：");
            int number = Input.input();
            login0.getUser(id).Money += number;
            FFactory.SaveObject(path0, login0);
            //hero.Money += number;
            Console.Clear();
            Console.WriteLine("恭喜你成功充值了" + number + "金币");
            //FFactory.SaveObject(path1, member0);
            MainLayer(id);
        }

        public static void exit()
        {
            Environment.Exit(0);
        }

    }
}


