﻿namespace WindowsFormsApp1
{
    partial class desk
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(desk));
            this.User1 = new System.Windows.Forms.Label();
            this.User2 = new System.Windows.Forms.Label();
            this.deskNumber = new System.Windows.Forms.Label();
            this.DeskName = new System.Windows.Forms.Label();
            this.ing = new System.Windows.Forms.Label();
            this.addRoom = new System.Windows.Forms.LinkLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pic_left_img = new System.Windows.Forms.PictureBox();
            this.pic_right_img = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_left_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_right_img)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // User1
            // 
            this.User1.AutoSize = true;
            this.User1.Location = new System.Drawing.Point(-2, 51);
            this.User1.Name = "User1";
            this.User1.Size = new System.Drawing.Size(35, 12);
            this.User1.TabIndex = 2;
            this.User1.Text = "用户1";
            // 
            // User2
            // 
            this.User2.AutoSize = true;
            this.User2.Location = new System.Drawing.Point(142, 73);
            this.User2.Name = "User2";
            this.User2.Size = new System.Drawing.Size(35, 12);
            this.User2.TabIndex = 3;
            this.User2.Text = "用户2";
            // 
            // deskNumber
            // 
            this.deskNumber.AutoSize = true;
            this.deskNumber.Location = new System.Drawing.Point(84, 102);
            this.deskNumber.Name = "deskNumber";
            this.deskNumber.Size = new System.Drawing.Size(29, 12);
            this.deskNumber.TabIndex = 5;
            this.deskNumber.Text = "1001";
            // 
            // DeskName
            // 
            this.DeskName.AutoSize = true;
            this.DeskName.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DeskName.Location = new System.Drawing.Point(43, 0);
            this.DeskName.Name = "DeskName";
            this.DeskName.Size = new System.Drawing.Size(110, 21);
            this.DeskName.TabIndex = 6;
            this.DeskName.Text = "房间名：1111";
            // 
            // ing
            // 
            this.ing.AutoSize = true;
            this.ing.Location = new System.Drawing.Point(24, 119);
            this.ing.Name = "ing";
            this.ing.Size = new System.Drawing.Size(59, 12);
            this.ing.TabIndex = 7;
            this.ing.Text = "空闲中...";
            // 
            // addRoom
            // 
            this.addRoom.AutoSize = true;
            this.addRoom.Location = new System.Drawing.Point(127, 119);
            this.addRoom.Name = "addRoom";
            this.addRoom.Size = new System.Drawing.Size(53, 12);
            this.addRoom.TabIndex = 8;
            this.addRoom.TabStop = true;
            this.addRoom.Text = "进入房间";
            this.addRoom.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.addRoom_LinkClicked);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::WindowsFormsApp1.Properties.Resources.qp2;
            this.pictureBox3.Location = new System.Drawing.Point(65, 24);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(71, 75);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            this.pictureBox3.DoubleClick += new System.EventHandler(this.pictureBox3_DoubleClick);
            // 
            // pic_left_img
            // 
            this.pic_left_img.Image = ((System.Drawing.Image)(resources.GetObject("pic_left_img.Image")));
            this.pic_left_img.Location = new System.Drawing.Point(16, 66);
            this.pic_left_img.Name = "pic_left_img";
            this.pic_left_img.Size = new System.Drawing.Size(33, 33);
            this.pic_left_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_left_img.TabIndex = 0;
            this.pic_left_img.TabStop = false;
            // 
            // pic_right_img
            // 
            this.pic_right_img.Image = ((System.Drawing.Image)(resources.GetObject("pic_right_img.Image")));
            this.pic_right_img.Location = new System.Drawing.Point(154, 36);
            this.pic_right_img.Name = "pic_right_img";
            this.pic_right_img.Size = new System.Drawing.Size(38, 34);
            this.pic_right_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_right_img.TabIndex = 1;
            this.pic_right_img.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DeskName);
            this.groupBox1.Controls.Add(this.addRoom);
            this.groupBox1.Controls.Add(this.pic_left_img);
            this.groupBox1.Controls.Add(this.ing);
            this.groupBox1.Controls.Add(this.pic_right_img);
            this.groupBox1.Controls.Add(this.User1);
            this.groupBox1.Controls.Add(this.deskNumber);
            this.groupBox1.Controls.Add(this.User2);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Location = new System.Drawing.Point(17, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(204, 146);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // desk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Name = "desk";
            this.Size = new System.Drawing.Size(242, 155);
            this.Load += new System.EventHandler(this.desk_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_left_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_right_img)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pic_left_img;
        private System.Windows.Forms.PictureBox pic_right_img;
        private System.Windows.Forms.Label User1;
        private System.Windows.Forms.Label User2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label deskNumber;
        private System.Windows.Forms.Label DeskName;
        private System.Windows.Forms.Label ing;
        private System.Windows.Forms.LinkLabel addRoom;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}
