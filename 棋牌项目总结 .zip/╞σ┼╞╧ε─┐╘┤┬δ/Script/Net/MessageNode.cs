﻿namespace util.net
{
    public struct MessageNode
    {
        public int Type;
        public ByteBuffer buffer;
    }
}