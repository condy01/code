﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace util.net
{
    public class messageQueue
    {
        /// <summary>
        /// 消息队列
        /// 不断从队列中读取消息
        /// 当需要停止时，就暂停执行
        /// 当开始读取时，就恢复读取执行
        /// </summary>
        //消息队列
        private ConcurrentQueue<ByteBuffer> queue = new ConcurrentQueue<ByteBuffer>();
        //信号
        private static EventWaitHandle Moinst = new AutoResetEvent(false);
        //是否等待
        private bool iswite = false;
        //是否启动
        private bool isRuning = false;
        //是否停止
        private bool _stopRead = false;
        //单例
        private static messageQueue _mq = null;

        public static messageQueue ShareMessageQueue()
        {
            if (_mq == null) _mq = new messageQueue();
            return _mq;
        }

        public void AddTask(ByteBuffer buffer)
        {
            Console.WriteLine(buffer.Type);
            this.queue.Enqueue(buffer);
            if (this.iswite)
            {
                Moinst.Set();
            }

            if (!isRuning)
            {
                isRuning = true;
                this.RunTaskAsyn();
            }
        }

        public void RunTaskAsyn()
        {
            //要不要继续执行
            if (!_stopRead)
            {
                Action ac = new Action(RunTask);
                ac.BeginInvoke(RunTaskEnd, ac);
            }

        }
        public void RunTaskEnd(IAsyncResult ar)
        {
            Action a = ar.AsyncState as Action;
            a.EndInvoke(ar);
            RunTaskAsyn();
            //RunTaskAsyn();
        }
        //停止读取
        public void StopRead()
        {
            this._stopRead = true;
        }
        //开始读取
        public void StartRead()
        {
            this._stopRead = false;
            this.RunTaskAsyn();
        }

        public void RunTask()
        {
            if (this.queue.IsEmpty)
            {
                this.iswite = true;
                Moinst.WaitOne();
                this.iswite = false;
            }
            ByteBuffer buf;
            this.queue.TryDequeue(out buf);
            core.EventDispatch.dispatchEvent(buf.Type, buf);
        }
    }
}
