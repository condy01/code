﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace util.net
{
    public class IP
    {
        public static string ip = "192.168.0.105";
        public static int port = 8888;
    }
}
