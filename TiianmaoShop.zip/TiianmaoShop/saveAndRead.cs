﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace TiianmaoShop
{
    class saveAndRead
    {
        public static Dictionary<int,goods> readXML(string url)
        {
            XElement xe = XElement.Load(url);
            var elements = from ele in xe.Elements()
                           select ele;

            Dictionary<int,goods> dictionary = new Dictionary<int, goods>();

            foreach (var ele in elements)
            {
               int  GoodsId = Convert.ToInt32(ele.Attribute("id").Value);
               string GoodsName = ele.Element("name").Value;
                int GoodsStock = Convert.ToInt32(ele.Element("stock").Value);
               int  GoodsPrice = Convert.ToInt32(ele.Element("price").Value);
                goods goods = new goods(GoodsId,GoodsName,GoodsPrice,GoodsStock );
                dictionary.Add(goods.Id, goods);
            }
            return dictionary;
        }
        /// <summary>
        /// 根据id修改XML文件
        /// </summary>
        /// <param name="url">要修改的目录文件路径</param>
        /// <param name="id">商品编号</param>
        /// <param name="list">商品信息</param>
        public static void change(string url, int id, Dictionary<int, goods> dictionary)
        {
            XElement xe = XElement.Load(@url);
            //int goodID = id;
            var elements = from ele in xe.Elements()
                           where (string)ele.Attribute("id") == id + ""
                           select ele;
            if (elements.Count() > 0)
            {

                XElement first = elements.First();
                ///设置新的属性
                first.SetAttributeValue("id", id);
                ///替换新的节点
                first.ReplaceNodes(
                         new XElement("name", dictionary[id].Name),
                         new XElement("stock", dictionary[id].Number),
                         new XElement("price", dictionary[id].Money)
                         );
            }
            xe.Save(@url);
            Console.WriteLine("修改成功！");
        }

    }
}
