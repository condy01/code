﻿namespace WindowsFormsApp1
{
    partial class chat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TextBox textBox1;
            this.onlineList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.talk = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.toName = new System.Windows.Forms.Label();
            this.allTalk = new System.Windows.Forms.RadioButton();
            this.oneTalk = new System.Windows.Forms.RadioButton();
            textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // onlineList
            // 
            this.onlineList.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.onlineList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.onlineList.FullRowSelect = true;
            this.onlineList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.onlineList.HideSelection = false;
            this.onlineList.HoverSelection = true;
            this.onlineList.Location = new System.Drawing.Point(647, 12);
            this.onlineList.Name = "onlineList";
            this.onlineList.Scrollable = false;
            this.onlineList.Size = new System.Drawing.Size(129, 304);
            this.onlineList.TabIndex = 0;
            this.onlineList.UseCompatibleStateImageBehavior = false;
            this.onlineList.View = System.Windows.Forms.View.Details;
            //this.onlineList.SelectedIndexChanged += new System.EventHandler(this.onlineList_SelectedIndexChanged);
            this.onlineList.Click += new System.EventHandler(this.onlineList_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "昵称";
            this.columnHeader1.Width = 67;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "账号";
            this.columnHeader2.Width = 72;
            // 
            // talk
            // 
            this.talk.Location = new System.Drawing.Point(12, 348);
            this.talk.Multiline = true;
            this.talk.Name = "talk";
            this.talk.Size = new System.Drawing.Size(606, 90);
            this.talk.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(647, 348);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 90);
            this.button1.TabIndex = 3;
            this.button1.Text = "发送";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // toName
            // 
            this.toName.AutoSize = true;
            this.toName.Location = new System.Drawing.Point(13, 330);
            this.toName.Name = "toName";
            this.toName.Size = new System.Drawing.Size(83, 12);
            this.toName.TabIndex = 4;
            this.toName.Text = "正在给 发消息";
            // 
            // allTalk
            // 
            this.allTalk.AutoSize = true;
            this.allTalk.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.allTalk.Location = new System.Drawing.Point(359, 318);
            this.allTalk.Name = "allTalk";
            this.allTalk.Size = new System.Drawing.Size(67, 24);
            this.allTalk.TabIndex = 5;
            this.allTalk.Text = "群聊";
            this.allTalk.UseVisualStyleBackColor = true;
            // 
            // oneTalk
            // 
            this.oneTalk.AutoSize = true;
            this.oneTalk.Checked = true;
            this.oneTalk.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.oneTalk.Location = new System.Drawing.Point(472, 318);
            this.oneTalk.Name = "oneTalk";
            this.oneTalk.Size = new System.Drawing.Size(67, 24);
            this.oneTalk.TabIndex = 6;
            this.oneTalk.TabStop = true;
            this.oneTalk.Text = "私聊";
            this.oneTalk.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            textBox1.Enabled = false;
            textBox1.Location = new System.Drawing.Point(12, 12);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new System.Drawing.Size(606, 300);
            textBox1.TabIndex = 8;
            // 
            // chat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(textBox1);
            this.Controls.Add(this.oneTalk);
            this.Controls.Add(this.allTalk);
            this.Controls.Add(this.toName);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.talk);
            this.Controls.Add(this.onlineList);
            this.Name = "chat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "聊天室";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView onlineList;
        private System.Windows.Forms.TextBox talk;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label toName;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.RadioButton allTalk;
        private System.Windows.Forms.RadioButton oneTalk;
    }
}