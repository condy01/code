﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.core;
using util.net;

namespace WindowsFormsApp1
{
    public partial class Login : Form
    {
       public static Login f;

        setIP setIP = new setIP();

        bool check = false;
        public Login()
        {
            f = this;

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string IP = setIP.ip.Text;
            int dk = int.Parse(setIP.duanko .Text);
            this.Show();
            U3DSocket u3DSocket = U3DSocket.shareSocket();
            u3DSocket.ConnectTo(IP, dk, () =>
            {
                //MessageBox.Show("连接成功");
            }, (str) =>
            {
                MessageBox.Show("连接失败，请稍后尝试！");
            }, 30);
            EventDispatch.addEventListener(this,"com",this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            regWin reg = new regWin();
            reg.Show();
            this.Hide();
            /*
            U3DSocket socket = U3DSocket.shareSocket();
            socket.ConnectTo("192.168.1.102", 8888,connectComplete, (str) => 
            {
                connectError();
            }, 30);*/
        }
        /*
        private void connectComplete()
        {
            ByteBuffer buffer = ByteBuffer.CreateBufferAndType(1002);

            buffer.writeString(this.id.Text);
            buffer.writeString(this.password.Text);
            buffer.Send();
            //do1002(buffer);
            //MessageBox.Show("登录成功","登录提示");
            

        }
        */
        private void connectError()
        {
            MessageBox.Show("登录失败");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void check_Click(object sender, EventArgs e)
        {
           // MessageBox.Show("你点击了按钮");
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string id = this.id.Text;
            string password = this.password.Text;
            ByteBuffer buffer = ByteBuffer.CreateBufferAndType(1001);

            buffer.writeString(id);
            buffer.writeString(password);

            buffer.Send();
            //MessageBox.Show(str);
        }
        public void com1001(ByteBuffer buffer)
        {
            //MessageBox.Show("登录成功", "登录提示");
            //chat form2 = new chat();
            //form2.Show();
            Player p = Player.sharePlayer();
            p.Id = buffer.readString();
            p.Name = buffer.readString();
            p.money = buffer.readInt();
            p.Duanwei = buffer.readString();
            p.img = buffer.readString();
            p.text = buffer.readString();
            //暂停读取消息
            messageQueue.ShareMessageQueue().StopRead();
            //打开游戏主界面
            GameHall hall = new GameHall();
            hall.Show();
            this.Hide();
        }
        public void com1002(ByteBuffer buffer)
        {
            //MessageBox.Show("55555555555");
            int name = buffer.readInt();
            MessageBox.Show("注册成功", "登录提示");
        }
        public void com120(ByteBuffer buffer)
        {
            string msg = buffer.readString();
            MessageBox.Show(msg);
        }


        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void id_TextChanged(object sender, EventArgs e)
        {

        }

        private void id_Click(object sender, EventArgs e)
        {
            if (check == false)
            {
                this.id.Text = "";
                check = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            setIP.Show();
        }
        /*
private void button5_Click(object sender, EventArgs e)
{
ByteBuffer buffer = ByteBuffer.CreateBufferAndType(5001);
buffer.Send();

}*/
    }
}
