﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.core;
using util.net;

namespace WindowsFormsApp1
{
    public partial class chat : Form
    {
        public chat()
        {
            InitializeComponent();
            ByteBuffer buffer = ByteBuffer.CreateBufferAndType(5001);
            buffer.Send();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            EventDispatch.addEventListener(this, "com");
        }
        public void com1003(ByteBuffer buffer)
        {
            int a = buffer.readInt();
            //MessageBox.Show(a+"");
            string b = buffer.readString();
            string c = buffer.readString();
            if (a == -1)
            {
                //MessageBox.Show(b + " " + c + "离开");
                ListViewItem item = new ListViewItem();
                //删除一行的方法
                for (int i = 0; i < onlineList.Items.Count; i++)
                {
                    if (onlineList.Items[i].SubItems[0].Text == b)
                    {
                        onlineList.Items.RemoveAt(i);
                        i--;
                    }
                }
            }
            else
            {
                //MessageBox.Show(b + " " + c + "进入");
                ListViewItem item = new ListViewItem();
                //添加一行的方法
                item.Text = b;
                //依次添加后面列的数据：
                item.SubItems.Add(c);

                onlineList.Items.Add(item);
            }
        }

        public void com2001(ByteBuffer buffer)
        {
            string str1=buffer.readString();
            string str2=buffer.readString();
            string str3=buffer.readString();
            ListViewItem item = new ListViewItem();
            //添加一行的方法
            //ChatRecord.Items.Add(str2+"【"+ str1 + "】"+"对大家说："+ str3);
            //textBox1.Text += str2 + "【" + str1 + "】" + "对大家说：" + str3+"\r\n";
        }
        public void com2002(ByteBuffer buffer)
        {
            string str1 = buffer.readString();
            string str2 = buffer.readString();
            string str3 = buffer.readString();
            ListViewItem item = new ListViewItem();
            //添加一行的方法
            //ChatRecord.Items.Add(str2 + "【" + str1 + "】" + "私聊你说：" + str3);
            //textBox1.Text += str2 + "【" + str1 + "】" + "私聊你说：" + str3+"\r\n";
        }

        public void com5001(ByteBuffer buffer)
        {
            string msg = buffer.readString();
            
            string[] a = new string[1000];
            string[] b = new string[a.Length];
            string[] c = new string[a.Length];
            a = msg.Split('@');
            for (int i = 0; i < a.Length; i++)
            {
                b[i] = a[i].Split('#')[1];
                c[i] = a[i].Split('#')[0];
            }
            
            for (int i = 0; i < a.Length; i++)
            {
                ListViewItem item = new ListViewItem();
                //添加一行的方法
                item.Text = b[i];
                //依次添加后面列的数据：
                item.SubItems.Add(c[i]);

                onlineList.Items.Add(item);
                //onlineList.Items.Add(c[i]);
            }
            //MessageBox.Show(msg);
            
        }
        

        private void onlineList_Click(object sender, EventArgs e)
        {
            //ListView list = (ListView)sender;

            String STR = onlineList.SelectedItems[0].Text;
            //String STR = list.SelectedItems[0].Text;
            //MessageBox.Show(STR);
            toName.Text = "正在给" + STR + "发消息";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.allTalk.Checked)
            {
                ByteBuffer byteBuffer = ByteBuffer.CreateBufferAndType(2001);
                string str=this.talk.Text;
                byteBuffer.writeString(str);
                byteBuffer.Send();
                this.talk.Text = null;
            }
            else
            {
                ByteBuffer byteBuffer = ByteBuffer.CreateBufferAndType(2002);
                string str = this.talk.Text;
                string name = onlineList.SelectedItems[0].SubItems[1].Text;
                if (name == null)
                {
                    MessageBox.Show("请选择要私聊的对象！");
                }
                else
                {
                    byteBuffer.writeString(name);
                    byteBuffer.writeString(str);
                    byteBuffer.Send();
                    this.talk.Text = null;
                }
            }
        }
        
    }
}
