﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiianmaoShop
{
    class Admin
    {
        public static List<Member> members = new List<Member>();

        internal List<Member> Members { get => members; set => members = value; }

        public static void add(Member member)
        {
           members.Add(member);
        }
        public static void print()
        {
            for(int i=0;i<members.Count; i++)
            {
                members[i].tostring();
            }
        }

        public static Member find(int id)
        {
            for (int i = 0; i < members.Count; i++)
            {
                if (members[i].Id == id)
                {
                    return members[i];
                }
            }
            return null;
        }

        public static String[] print0()
        {
            String[] arr = new String[members.Count];
            for (int i = 0; i < members.Count; i++)
            {
                arr[i]=members[i].tostring0();
            }
            return arr;
        }
    }
}
