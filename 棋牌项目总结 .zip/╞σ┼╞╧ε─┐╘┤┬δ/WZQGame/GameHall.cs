﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using util.core;
using util.net;

namespace WindowsFormsApp1
{
    public partial class GameHall : Form
    {

        public GameHall()
        {
            

            InitializeComponent();
            //Control.CheckForIllegalCrossThreadCalls = false;
            GameHallLogic game = new GameHallLogic(this);

            GameLogic g = new GameLogic();
            
            //ByteBuffer buffer = ByteBuffer.CreateBufferAndType(5001);
            //buffer.Send();
        }

        private void GameHall_Load(object sender, EventArgs e)
        {
            setMessage();
            Task.Run(() => {
                Thread.Sleep(300);
                messageQueue.ShareMessageQueue().StartRead();

                //ByteBuffer byteBuffer = ByteBuffer.CreateBufferAndType(6210);
                //byteBuffer.Send();
                
            });
            

        }
        private void setMessage()
        {
            this.name.Text = Player.sharePlayer().Name;
            this.money.Text = Player.sharePlayer().money + "";
            this.duanwei.Text = Player.sharePlayer().Duanwei;
            this.text.Text = Player.sharePlayer().Name;
            this.pic.LoadAsync(Player.sharePlayer().img == "null" ? null : Player.sharePlayer().img);
        }
        
        private void onlineList_MouseClick(object sender, MouseEventArgs e)
        {
            //ListView list = (ListView)sender;
            String STR = onlineList.SelectedItems[0].SubItems[1].Text;
            //MessageBox.Show(STR);
            toName0.Text = "正在给" + STR + "发消息";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (this.allTalk.Checked)
            {
                ByteBuffer byteBuffer = ByteBuffer.CreateBufferAndType(2001);
                string str = this.talk.Text;
                byteBuffer.writeString(str);
                byteBuffer.Send();
                this.talk.Text = null;
            }
            else if(this.oneTalk.Checked)
            {
                ByteBuffer byteBuffer = ByteBuffer.CreateBufferAndType(2002);
                string str = this.talk.Text;
                string name = onlineList.SelectedItems[0].SubItems[0].Text;
                if (name == null)
                {
                    MessageBox.Show("请选择要私聊的对象！");
                }
                else
                {
                    byteBuffer.writeString(name);
                    byteBuffer.writeString(str);
                    byteBuffer.Send();
                    this.talk.Text = null;
                }
            }
        }

        private void ChatMessage_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void GameHall_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
