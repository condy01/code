﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace util.net
{
    public class Protcol
    {
        public const int 加入房间 = 6310;
        public const int 游戏准备 = 7006;
        public const int 取消准备 = 7007;
        public const int 离开房间 = 7999;
        public static int 玩家走棋 = 7111;
        public static int 私聊 = 2002;
        public static int 群聊 = 2001;
    }
}
